---- <b>CST3145 Group Coursework</b> ----
    <br> <br>
    - Github page URL: https://githubpage.com

    - Group members:
      - Wiktor - M00780216 - WK186@LIVE.MDX.AC.UK
      - Abdul-Rasaq {{ M00755048 }} - {{ AA4818@live.mdx.ac.uk}}
      - Tee {{ add your student number }} - {{ add your student email }}
      - Abdul-matin Adebayo - M00869707 - AA5328@LIVE.MDX.AC.UK

 ----- <b>External libraries</b> -----    
  
    - Bootstrap
      - https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css
    
    - Vue
      - https://unpkg.com/vue@2.7.8/dist/vue.js
      
    - Google fonts
      - https://fonts.googleapis.com
      - https://fonts.gstatic.com
      - https://fonts.googleapis.com/css2?family=Poppins&display=swap
