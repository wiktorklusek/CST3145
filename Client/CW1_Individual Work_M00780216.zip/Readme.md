---- <b>CST3145 Group Coursework</b> ----
    <br> <br>
    - <b>Github URL:</b> https://github.com/wiktorklusek/CST3145 <br>
    - <b>Github page URL:</b> https://wiktorklusek.github.io/CST3145/

    - Group members:
      - Wiktor Klusek - M00780216 - WK186@LIVE.MDX.AC.UK
      - Abdul-Rasaq Akewusure - M00755048 - AA4818@live.mdx.ac.uk
      - Theevahar Srirangan - M00675232 - TS853@live.mdx.ac.uk
      - Abdul-Matin Adebayo - M00869707 - AA5328@LIVE.MDX.AC.UK
      - Jan Ciepiela - M00779169 - JC1663@live.mdx.ac.uk

 ----- <b>External libraries</b> -----    
  
    - Bootstrap
      - https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css
    
    - Vue
      - https://unpkg.com/vue@2.7.8/dist/vue.js
      
    - Google fonts
      - https://fonts.googleapis.com
      - https://fonts.gstatic.com
      - https://fonts.googleapis.com/css2?family=Poppins&display=swap
